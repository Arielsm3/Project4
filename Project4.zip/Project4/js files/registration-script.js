function registration() {

    var name = document.getElementById("name");
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var organization = document.getElementById("organization").value;
    var country = document.getElementById("country").value;
    var regType = document.getElementById("registration-type").value;
    var password = document.getElementById("password").value;
    var confirm_password = document.getElementById("confirm-password").value;
    var discount = document.getElementById("discount-code").value;

	var password_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])/;
	var letters = /^[A-Za-z]+$/;
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{10,20})+$/;

    

        if(name=="") {
            document.getElementById("1").style.display = "block";
        }
        
        else if(letters.test(name)) {
            document.getElementById("1").style.display = "block";
        }
        
        else if(email=="") {
            document.getElementById("2").style.display = "block";
        }
        
        else if(!filter.test(email)) {
            document.getElementById("2").style.display = "block";
        }
        
        else if(organization=="") {
            document.getElementById("3").style.display = "block";
        }
        
        else if(password=="") {
            document.getElementById("4").style.display = "block";
        }

        else if(confirm_password!==password) {
            document.getElementById("7").style.display = "block";
        }

        else if(country="") {
            document.getElementById("9").style.display = "block";
        }

        else if(phone=/^(\()?\d{3}(\))?(-|\s)?\d{3}(-|\s)\d{4}$/) { /* Thanks to Stack Overflow for the phone number format validation code (only useful in North America)*/
            document.getElementById("10").style.display = "block";
        }

        
        else if(!password_expression.test(password)) {
            document.getElementById("4").style.display = "block";
            document.getElementById("5").style.display = "block";
            document.getElementById("6").style.display = "block";
        }
        
        else if(password.length < 10 || password.length > 20) {
            document.getElementById("3").style.display = "block";
        }
        
        else {
            document.getElementById("all-items").style.display = "none";
            document.getElementById("forErrors").style.display = "none";
        } 

}